#!/bin/bash

PATH=/home/pi/holidays
TIMER=2

COMPATH=/home/pi/rpi-rgb-led-matrix/led-matrix

while true; do

for filename in $PATH/*.pbm; do
#    for ((i=0; i<=3; i++)); do
#        ./MyProgram.exe "$filename" "Logs/$(basename "$filename" .txt)_Log$i.txt"
#    done
#	echo $filename

	$COMPATH -d -r 16 -c 2 -D 1 -t $TIMER $filename
	/bin/sleep $((TIMER+1))
done

done


#// ANIMATION_GreenCyanPink_Easter.pbm ANIMATION_GreenOrange_St.Patricks.pbm ANIMATION_GreenRed_Christmas.pbm ANIMATION_Multicolor_NewYears.pbm ANIMATION_OrangePurple_Halloween.pbm ANIMATION_OrangeYellow_Thanksgiving.pbm ANIMATION_RedPink_Valentines.pbm Cyan_Easter.pbm GreenRed_Christmas.pbm Green_StPatricks.pbm MultiColor_NewYears.pbm Orange_Halloween.pbm Purple_Valentines.pbm RedWhiteBlue_FourthofJuly.pbm startupTest.sh White_EverdayLighting.pbm Yellow_Thanksgiving.pbm
